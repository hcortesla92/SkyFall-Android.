[app]
title = SkyFall
project_dir = .
input_file = main.py
project_file = pyproject.toml
exec_directory = .

[python]
# The Android deploy tool installs buildozer/Cython as needed.
android_packages = buildozer,cython

[qt]
# Keep the core Qt modules used by SkyFall. WebEngine is optional on Android;
# main.py contains a safe fallback when the module is not present.
modules = Core,Gui,Widgets,Network,UiTools

[android]
# Download the matching Android wheels for the architecture being built.
# Replace these paths with the downloaded wheels before building.
wheel_pyside = /PATH/TO/PySide6-ANDROID-WHEEL.whl
wheel_shiboken = /PATH/TO/Shiboken6-ANDROID-WHEEL.whl
plugins = platforms,styles,imageformats

[buildozer]
mode = debug
arch = aarch64
