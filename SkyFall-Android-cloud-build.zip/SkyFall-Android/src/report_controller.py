import json
import os
import sys
from pathlib import Path

from loguru import logger
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from PySide6.QtWidgets import QApplication, QFileDialog


class ReportController:
    def __init__(self, ui, case_manager=None):
        self.ui = ui
        self.case_manager = case_manager
        self._generating = False
        self._ollama_base_url = "http://127.0.0.1:11434"

    async def update_ollama_models(self):
        import httpx

        try:
            async with httpx.AsyncClient() as client:
                resp = await client.get(f"{self._ollama_base_url}/api/tags", timeout=10)
                resp.raise_for_status()
                models = resp.json().get("models", [])
                self.ui.ollamaModelsSelector.clear()
                for m in models:
                    self.ui.ollamaModelsSelector.addItem(m["name"])
        except Exception as e:
            logger.error(f"Failed to fetch Ollama models: {e}")

    @staticmethod
    def _server_params() -> StdioServerParameters:
        server_script = Path(__file__).parent / "ollama_mcp_server.py"
        return StdioServerParameters(
            command=sys.executable,
            args=[str(server_script)],
        )

    async def _call_tool(self, tool_name: str, arguments: dict | None = None) -> str:
        params = self._server_params()
        async with stdio_client(params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.call_tool(tool_name, arguments or {})
                return result.content[0].text

    async def _call_tools(self, *calls: tuple[str, dict]) -> list[str]:
        params = self._server_params()
        async with stdio_client(params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                results = []
                for tool_name, arguments in calls:
                    result = await session.call_tool(tool_name, arguments or {})
                    results.append(result.content[0].text)
                return results

    async def generate_report(self):
        if self._generating:
            logger.warning("Report generation already in progress")
            return

        self._generating = True
        try:
            self.ui.aiReportDebug.setPlainText("Generating report...")
            QApplication.processEvents()

            data = self._collect_all_data()
            language = self.ui.aiReportLangEdit.text().strip() or "Russian"

            prelude = [
                ("set_ollama_url", {"url": self._ollama_base_url}),
            ]
            model = self.ui.ollamaModelsSelector.currentText()
            if model:
                prelude.append(("set_ollama_model", {"model_name": model}))

            results = await self._call_tools(
                *prelude,
                (
                    "generate_osint_report",
                    {
                        "app_data": json.dumps(data, ensure_ascii=False, default=str),
                        "language": language,
                    },
                ),
            )
            report_text = results[-1]

            if report_text and report_text.strip():
                self.ui.aiReportDebug.setPlainText(report_text)
                logger.success("OSINT report generated")
            else:
                self.ui.aiReportDebug.setPlainText(
                    "# Error\n\nEmpty report received from model. "
                    "Check Ollama is running and the model is available."
                )
                logger.error("Empty report text received from Ollama")

        except Exception as e:
            error_msg = f"Error generating report: {e}"
            logger.error(error_msg)
            self.ui.aiReportDebug.setPlainText(f"# Error\n\n{error_msg}")
        finally:
            self._generating = False

    def _collect_all_data(self) -> dict:
        data = {}

        debug_widgets = {
            "telegram_downloader": self.ui.telegramDownloaderDebug,
            "telegram_analyzer": self.ui.telegramAnalyzerDebug,
            "username_results": self.ui.usernameResultsDebug,
            "mail_search": self.ui.mailSearchDebug,
            "hibp_check": self.ui.hibpDebug,
            "email_headers": getattr(self.ui, "emailHeaderDebug", None),
            "server_location": self.ui.serverLocationDebug,
            "server_robots": self.ui.serverRobotsDebug,
            "server_tls": self.ui.serverTlsDebug,
            "server_waf": self.ui.serverWafDebug,
            "cookies": self.ui.cookiesDebug,
            "security_txt": self.ui.securityTxtDebug,
            "server_subdomains": self.ui.serverSubdomainsDebug,
            "social_tags": self.ui.socialTagsDebug,
            "server_nmap": self.ui.serverNmapDebug,
            "server_dns": self.ui.serverDnsAnalyzeDebug,
            "server_whois": self.ui.serverWhoisDebug,
            "server_malware": self.ui.serverMalwareDebug,
            "threat_intel": getattr(self.ui, "serverThreatIntelDebug", None),
            "js_secrets": getattr(self.ui, "serverJsSecretsDebug", None),
            "cert_transparency": self.ui.certTrDebug,
            "metadata": self.ui.metadataDebug,
            "strings": self.ui.stringsFileDebug,
            "virustotal_file": self.ui.virustotalFileDebug,
            "github": self.ui.githubDebug,
            "phone": self.ui.phoneDebug,
            "mac_location": self.ui.macAddrLocationDebug,
            "blockchain": self.ui.bcDebug,
            "steganography_ela": getattr(self.ui, "elaDebug", None),
        }

        placeholders = {"REPORT", "INTELX", "HIBP", "METADATA", "VIRUSTOTAL", "STRINGS"}

        for name, widget in debug_widgets.items():
            if widget is None:
                continue
            text = widget.toPlainText().strip()
            if text and text not in placeholders:
                data[name] = text

        try:
            data["graph"] = self.ui.graphWidget.to_dict()
        except Exception:
            pass

        inputs = {
            "url": self.ui.serverUrlEdit.text(),
            "username": self.ui.usernameEdit.text(),
            "email": self.ui.mailEdit.text(),
            "phone": self.ui.phoneNumberEdit.text(),
            "mac_address": self.ui.macAddrEdit.text(),
            "github_user": self.ui.githubUserEdit.text(),
            "github_repo": self.ui.githubRepoEdit.text(),
        }
        data["search_inputs"] = {k: v for k, v in inputs.items() if v}

        return data

    def save_report(self):
        report_text = self.ui.aiReportDebug.toPlainText()
        if not report_text or report_text in ("REPORT", "Generating report..."):
            return

        data_dir = (
            self.case_manager.get_reports_dir()
            if self.case_manager
            else str(Path.home() / ".skyfall" / "data")
        )
        os.makedirs(data_dir, exist_ok=True)

        path, _ = QFileDialog.getSaveFileName(
            self.ui,
            "Save Report",
            os.path.join(data_dir, "osint_report.md"),
            "Markdown (*.md)",
        )

        if path:
            Path(path).write_text(report_text, encoding="utf-8")
            logger.success(f"Report saved to {path}")
