#!/usr/bin/env bash
set -euo pipefail

# SkyFall Android build helper.
# Run this on Linux/macOS with Python 3.10+, JDK 17+, Android SDK/NDK.
# Current Qt for Python docs require NDK r28c (28.2.13676358).

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

python3 -m pip install --upgrade pip
python3 -m pip install PySide6==6.11.1 buildozer cython

if [[ -z "${PYSIDE_WHEEL:-}" || -z "${SHIBOKEN_WHEEL:-}" ]]; then
  echo "Set PYSIDE_WHEEL and SHIBOKEN_WHEEL to the downloaded Android wheels."
  echo "Example:"
  echo "  export PYSIDE_WHEEL=/path/PySide6-...aarch64.whl"
  echo "  export SHIBOKEN_WHEEL=/path/Shiboken6-...aarch64.whl"
  exit 2
fi

python3 -m pip install "$PYSIDE_WHEEL" "$SHIBOKEN_WHEEL"

pyside6-android-deploy \
  --name "SkyFall" \
  --wheel-pyside "$PYSIDE_WHEEL" \
  --wheel-shiboken "$SHIBOKEN_WHEEL" \
  --config-file "$ROOT/pysidedeploy.spec" \
  --force

echo "APK/AAB output is in the project directory/build output reported by pyside6-android-deploy."
