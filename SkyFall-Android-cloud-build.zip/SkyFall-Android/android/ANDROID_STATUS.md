# SkyFall Android port

This tree is prepared for Qt for Python's official `pyside6-android-deploy` flow.

## Important compatibility notes

SkyFall was originally written as a desktop application. The Android port keeps the
existing Python modules and UI and makes the Qt WebEngine import optional. Some
features depend on desktop/native programs or services and therefore need an
Android-specific implementation or remote backend to be fully equivalent:

- Nmap (`python-nmap` expects the Nmap executable on the host)
- Docker/SearXNG local deployment
- desktop system proxy integration
- subprocess-based MCP helpers
- some filesystem paths and desktop-specific integrations

The port does **not** silently claim those features are equivalent on Android.
They should be tested one by one after the APK launches.

## Building

Qt's current Android deployment documentation requires a Unix host, Python 3.10+
and JDK 17+. It also currently specifies Android NDK r28c (`28.2.13676358`).
The official tool is `pyside6-android-deploy`.

See `android/build-apk.sh` for the repeatable build command.
